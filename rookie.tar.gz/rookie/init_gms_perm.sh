#!/system/bin/sh

/system/bin/pm grant com.google.android.gms android.permission.ACCESS_FINE_LOCATION
/system/bin/pm grant com.google.android.gms android.permission.READ_EXTERNAL_STORAGE
