#!/system/bin/sh

iproxy 7210 7240 &
iproxy 8210 8240 &
iproxy 9210 9240 &
iproxy 9211 9241 &
iproxy 9212 9242 &
iproxy 9310 9340 &
